package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.app.entity.Product;
import com.app.service.ProductService;

@RestController
@RequestMapping("/api/products")
@CrossOrigin
public class ProductController {

    @Autowired
    private ProductService service;

    @GetMapping
    public List<Product> getAll() {
        return service.getAll();
    }

    @PostMapping
    public Product add(@RequestBody Product p) {
        return service.save(p);
    }

    @PutMapping("/purchase/{code}/{qty}")
    public Product purchase(@PathVariable String code, @PathVariable int qty) {
        return service.updateStock(code, qty);
    }
}
