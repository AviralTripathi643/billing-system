package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import com.app.entity.Product;
import com.app.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repo;

    public List<Product> getAll() {
        return repo.findAll();
    }

    public Product save(Product p) {
        return repo.save(p);
    }

    public Product updateStock(String code, int qty) {
        Product p = repo.findByCode(code);
        if (p == null) throw new RuntimeException("Product not found");
        if (qty > p.getStock()) throw new RuntimeException("Stock exceeded");

        p.setStock(p.getStock() - qty);
        return repo.save(p);
    }
}
