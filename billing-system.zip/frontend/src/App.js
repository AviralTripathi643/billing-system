import React from "react";

function App() {
  return (
    <div>
      <h1>Billing System</h1>
    </div>
  );
}

export default App;
